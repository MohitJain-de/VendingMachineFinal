﻿using IJPVendingMachine;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace VendingMachine.UnitTests
{
    [TestClass]
    public class VendingMachineTest
    {
        VendingMachine vendingMachine;

        [TestInitialize()]
        public void setup()
        {
            vendingMachine = new VendingMachine();
        }

        [DataRow("Vegetables")]
        [DataRow("Fruits")]
        [DataRow("Groceries")]
        [TestMethod]
        public void When_User_Enter_Invalid_Product_VendingMachine_Should_Return_Invalid_Product(string Product)
        {
            var vendingResponse = vendingMachine.SelectProduct(new Product() { Name = Product });

            Assert.AreEqual(vendingResponse, false);
        }

        [DataRow("cola")]
        [DataRow("chips")]
        [TestMethod]
        public void When_User_Enter_valid_Product_VendingMachine_Should_Return_valid_Product(string Product)
        {
            var vendingResponse = vendingMachine.SelectProduct(new Product() { Name = Product });

            Assert.AreEqual(vendingResponse, true);
        }

        [DataRow("cola", "dimess")]
        [DataRow("chips", "rupees")]
        [TestMethod]
        public void When_User_Enter_valid_Product_Invalid_Coin_VendingMachine_Should_Return_valid_Product_Invalid_Coin(string Product, string Coin)
        {
            var vendingResponse = vendingMachine.SelectProduct(new Product() { Name = Product });
            vendingResponse = vendingResponse == true ? vendingMachine.AcceptCoin(new Coin() { Type = Coin }, new Product() { Name = Product }) : vendingResponse;

            Assert.AreEqual(vendingResponse, false);
        }

        [DataRow("cola", "1.00", "nickels", "0.05")]
        [DataRow("chips", "0.50", "dimes", "0.10")]
        [TestMethod]
        public void When_User_Enter_valid_Product_valid_Coin_Amt_Lesser_VendingMachine_Should_Return_valid_Product_Enter_More_Coin(string Product, string Price, string Coin, string value)
        {
            decimal n1, n2;

            if (Decimal.TryParse(value, out n1) && Decimal.TryParse(Price, out n2))
            {
                var vendingResponse = vendingMachine.SelectProduct(new Product() { Name = Product, Price = n2 });
                vendingResponse = vendingResponse == true ? vendingMachine.AcceptCoin(new Coin() { Type = Coin, Value = n1 }, new Product() { Name = Product, Price = n2 }) : vendingResponse;
                vendingMachine.ResetVendingMachine();

                Assert.AreEqual(vendingResponse, false);
            }
        }

        [TestMethod]
        [DynamicData(nameof(GetTestData), DynamicDataSourceType.Method)]
        public void When_User_Enter_valid_Product_valid_Coin_Amt_greater_VendingMachine_Should_Return_valid_Product_Return_Exchange_Coin(IEnumerable<Coin> Coins)
        {
            Product prod = new Product() { Name = "candy", Price = 0.65m };
            var vendingResponse = vendingMachine.SelectProduct(prod);
            foreach (var coin in Coins)
            {
                vendingResponse = vendingMachine.AcceptCoin(coin, prod);
            }

            Assert.AreEqual(vendingResponse, true);
            Assert.AreEqual(VendingMachine.ReturnAmount, 0.10m);
            Assert.AreEqual(VendingMachine.ReturnCoins.Where(x => x.Type == "nickels").Count(), 2);
            vendingMachine.ResetVendingMachine();
        }
        public static IEnumerable<object[]> GetTestData()
        {
            yield return new object[] { new List<Coin>() { new Coin() { Type = "quaters", Value = 0.25m }, new Coin() { Type = "quaters", Value = 0.25m }, new Coin() { Type = "quaters", Value = 0.25m } } };
        }
    }
}
