﻿using System.Collections.Generic;
using VendingMachine;

namespace IJPVendingMachine
{
    public static class VendingMachineConstants
    {
        public static readonly List<Product> Products = new List<Product>()
            {
                new Product() {Name = "cola",Price = 1.00m},
                new Product() {Name = "chips", Price = 0.50m},
                new Product() {Name = "candy", Price = 0.65m},
            };

        public static readonly List<Coin> Coins = new List<Coin>() {
                new Coin() {Type = "nickels",  Value = 0.05m},
                new Coin() { Type = "dimes",  Value = 0.10m},
                new Coin() { Type = "quaters", Value = 0.25m},
        };
    }
}
