﻿using IJPVendingMachine;
using System;
using System.Collections.Generic;
using System.Linq;

namespace VendingMachine
{
    public class VendingMachine
    {
        private decimal TotalAmount = 0;
        private static VendindMachineState currentState = VendindMachineState.Ready;
        public static List<Coin> ReturnCoins = new List<Coin>();
        public static decimal ReturnAmount;

        public Boolean AcceptCoin(Coin coin, Product userSelectedProduct)
        {
            try
            {
                if (coin.Type == null)
                {
                    currentState = VendindMachineState.InvalidCoin;
                    return false;
                }
                else if (VendingMachineConstants.Coins.Find(x => x.Type == coin.Type) == null)
                {
                    currentState = VendindMachineState.InvalidCoin;
                    return false;
                }
                else
                {
                    TotalAmount += coin.Value;
                    if (TotalAmount < userSelectedProduct.Price)
                    {
                        currentState = VendindMachineState.InsufficientMoney;
                        return false;
                    }
                    else
                    {
                        DispenseProduct(userSelectedProduct);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void DispenseProduct(Product userSelectedProduct)
        {
            decimal extraAmount = Decimal.Subtract(TotalAmount, userSelectedProduct.Price);
            ReturnCoins = MakeChange(extraAmount);
            ReturnAmount = extraAmount;
            currentState = VendindMachineState.ProductDispensed;
        }

        public Boolean SelectProduct(Product productName)
        {
            try
            {
                if (productName.Name == null)
                {
                    currentState = VendindMachineState.InvalidProduct;
                    return false;
                }
                else if (VendingMachineConstants.Products.Find(x => x.Name == productName.Name) == null)
                {
                    currentState = VendindMachineState.InvalidProduct;
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private List<Coin> MakeChange(decimal change)
        {
            string ReturnChange = string.Empty;
            var coins = VendingMachineConstants.Coins;

            if (change == 0) return ReturnCoins;
            foreach (var coinType in coins.Select(x => x.Type))
            {
                var result = (decimal)(change / coins.Find(x => x.Type == coinType).Value);
                if (result > 0.00m)
                {
                    for (int i = 0; i < result; i++)
                    {
                        ReturnCoins.Add(VendingMachineConstants.Coins.Find(x => x.Type == coinType));
                    }
                    change = Math.Round(change - (result * coins.Find(x => x.Type == coinType).Value), 3);
                    var remainingAmount = change;
                    if (remainingAmount == 0)
                        return ReturnCoins;
                }
            }
            return ReturnCoins;
        }
        public bool ResetVendingMachine()
        {
            TotalAmount = 0;
            currentState = VendindMachineState.Ready;
            ReturnCoins = new List<Coin>();
            return true;
        }
    }
    public class Coin
    {
        public string Type { get; set; }
        public decimal Value { get; set; }
    }
    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
    internal enum VendindMachineState
    {
        Ready,
        InvalidProduct,
        InvalidCoin,
        InsufficientMoney,
        ProductDispensed
    }
}

