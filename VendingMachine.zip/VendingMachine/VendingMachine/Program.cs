﻿using IJPVendingMachine;
using System;
using System.Linq;

namespace VendingMachine
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }

    }
}
